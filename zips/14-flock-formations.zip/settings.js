// 起止时间使用秒，速度 1 表示原速。更改后刷新页面。
window.effectSettings = {"start": 6.5, "end": 13.5, "fps": 60, "speed": 1};

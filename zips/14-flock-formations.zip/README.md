# 鸟群方阵、圆环与波浪

来自「夏夏的AI灵感」2026-11-17 发布的《VibeCoding 八工具》。本包为原版核心提取，演示窗口长 7.00 秒。

## 从这里开始

1. 完整解压 ZIP，保留目录结构。
2. 双击 index.html，用浏览器打开。可以暂停、重播或拖动进度条。
3. 把本目录与「提示词.txt」一起交给 AI。先说要改哪个动作、颜色或文字，再对照预览检查。

## 画面与时间

25 只鸟先以连续切线落入五乘五方阵，以 19 毫秒组间错峰重排成环，再用 1.53 秒三次缓动铺成正弦波；飞向下一组目标。

源工程为「VibeCoding 八种工具 · v24」。时钟从 6.500 秒取到 13.500 秒。设置在 settings.js，speed 为 1 表示原速，0.5 表示半速。

使用原工程的几何、镜头、队形与碰撞数据，独立播放已选时间段。预览以 960 × 720 绘制。

## 工具、插件与实现

Three.js 0.180.0、EffectComposer、UnrealBloomPass、Anime.js 4.5.0、Tween.js 25.0.0。原片用 Ammo.js 计算刚体位姿，包中有原始 120 Hz 物理采样。

[Three.js](https://threejs.org/docs/) · [Anime.js](https://animejs.com/documentation/) · [Tween.js](https://github.com/tweenjs/tween.js) · [Ammo.js](https://github.com/kripken/ammo.js)

## 修改和嵌入

主绘制入口在 effect.js。用文本编辑器打开文件即可改，刷新浏览器就能检查。player.js 负责播放和定位，和绘图逻辑独立。

把完整组件目录放进自己的静态网站，使用 iframe 能隔开样式、动画时钟和点击事件。将路径换成组件的实际位置。

~~~html
<iframe src="./14-flock-formations/index.html" title="鸟群方阵、圆环与波浪" loading="lazy" style="width:100%;height:640px;border:0"></iframe>
~~~

## 检查自己的改版

从头播放，确认该动作有起点、过渡和稳定状态。暂停后拖到中段，再次回到同一位置应得到一致的姿势。调整速度后，确认轨迹与先后次序仍然一致。

## 复刻提示词

25 只鸟先以连续切线落入五乘五方阵，以 19 毫秒组间错峰重排成环，再用 1.53 秒三次缓动铺成正弦波；飞向下一组目标。 独立展示这个动作，遵循下载包的取景、时间范围和缓动，提供播放、暂停、重播与定位。

## 署名与许可

本包原创代码由夏夏的AI灵感提供，按 [MIT 许可](LICENSE.txt) 开放修改和商用。重新分发时保留署名及许可声明。随包第三方运行库与改编代码适用各自声明，详见 vendor 内的许可文件。

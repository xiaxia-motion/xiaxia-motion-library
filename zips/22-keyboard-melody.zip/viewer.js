// 夏夏的AI灵感 · 独立键盘组件预览与交互控制器（定稿演示 / 自己操作双模式）。
(() => {
  const get = (id) => document.getElementById(id);
  const cfg = window.EFFECT_SETTINGS || {};
  const UI = window.KeyboardUI;
  const spec = UI.config;
  const canvas = get("stage");
  const ctx = canvas.getContext("2d", { alpha: false });
  const progress = get("time");
  const playButton = get("play");
  const modeButton = get("mode");
  const soundButton = get("sound");
  const status = get("status");
  const readout = get("readout");

  const first = spec.start;
  const last = spec.end;
  const length = (last - first) / 60;
  const speed = Number(cfg.speed) || 1;
  const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const audio = window.KeyboardAudio ? window.KeyboardAudio.create() : null;
  const live = UI.createLive(audio);

  let mode = "demo";
  let running = false;
  let playTime = 0;
  let anchor = 0;
  let raf = 0;
  let paintedFrame = -1;
  let liveFrame = 0;

  function canvasPoint(e) {
    const b = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - b.left) / Math.max(1, b.width)) * 1200,
      y: ((e.clientY - b.top) / Math.max(1, b.height)) * 900,
    };
  }

  function position() {
    if (!running) return playTime;
    return (playTime + ((performance.now() - anchor) / 1000) * speed) % length;
  }

  function draw(now) {
    if (mode === "demo") {
      const pos = position();
      const frame = Math.min(last - 1, first + Math.floor(pos * 60 + 1e-7));
      if (frame !== paintedFrame) {
        UI.renderDemo(ctx, frame);
        paintedFrame = frame;
      }
      progress.value = pos;
      readout.value = pos.toFixed(2) + " / " + length.toFixed(2) + " 秒";
    } else {
      liveFrame += 1;
      UI.renderLive(ctx, live.sample(liveFrame), liveFrame);
    }
  }

  function schedule() {
    if (!raf) {
      raf = requestAnimationFrame((t) => {
        raf = 0;
        draw(t);
        if (running || mode === "live") schedule();
      });
    }
  }

  function pause() {
    playTime = position();
    running = false;
    playButton.textContent = "播放";
  }

  function play() {
    if (mode !== "demo") setMode("demo");
    if (running) return;
    if (playTime >= length) playTime = 0;
    anchor = performance.now();
    running = true;
    playButton.textContent = "暂停";
    schedule();
  }

  function seek(s) {
    if (mode !== "demo") setMode("demo");
    const was = running;
    pause();
    playTime = Math.min(length, Math.max(0, Number(s) || 0));
    paintedFrame = -1;
    draw(performance.now());
    if (was) play();
  }

  function setMode(next) {
    if (next === mode) return;
    pause();
    mode = next;
    const isLive = next === "live";
    get("timeline").hidden = isLive;
    get("actions").hidden = !isLive;
    modeButton.textContent = isLive ? "返回定稿演示" : "自己操作";
    modeButton.setAttribute("aria-pressed", String(isLive));
    status.textContent = isLive ? (cfg.hint || "直接点击屏幕键帽或使用实体键盘输入。") : "";
    if (isLive) {
      canvas.focus({ preventScroll: true });
      schedule();
    } else {
      paintedFrame = -1;
      draw(performance.now());
    }
  }

  function triggerKey(id) {
    if (mode !== "live") setMode("live");
    const msg = live.pressKey(id, liveFrame);
    if (msg) status.textContent = msg;
    schedule();
  }

  canvas.addEventListener("pointerdown", (e) => {
    const pt = canvasPoint(e);
    const hit = UI.hitTestKey(pt.x, pt.y);
    if (hit) {
      e.preventDefault();
      triggerKey(hit);
    } else if (mode === "demo") {
      running ? pause() : play();
    }
  });

  window.addEventListener("keydown", (e) => {
    if (mode !== "live") return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.target && e.target.tagName === "INPUT") return;
    let id = null;
    if (e.key === "Backspace") id = "Backspace";
    else if (e.key === "Enter") id = "Enter";
    else if (e.key === " ") id = "Space";
    else if (e.key === "Shift") id = "Shift";
    else if (/^[a-zA-Z]$/.test(e.key)) id = e.key.toUpperCase();
    if (id) {
      e.preventDefault();
      triggerKey(id);
    }
  });

  playButton.onclick = () => (running ? pause() : play());
  get("restart").onclick = () => {
    pause();
    seek(0);
    play();
  };
  progress.min = 0;
  progress.max = length;
  progress.step = 1 / 60;
  progress.oninput = () => {
    pause();
    seek(+progress.value);
  };
  modeButton.onclick = () => setMode(mode === "demo" ? "live" : "demo");

  Array.from(get("actions").querySelectorAll("button[data-act]")).forEach((btn) => {
    btn.onclick = () => {
      const act = btn.getAttribute("data-act");
      const msg = live.action(act, liveFrame);
      if (msg) status.textContent = msg;
      schedule();
    };
  });

  if (soundButton && audio) {
    soundButton.onclick = async () => {
      try {
        const on = await audio.toggle();
        soundButton.setAttribute("aria-pressed", String(on));
        soundButton.textContent = on ? "关闭声音" : "开启声音";
      } catch {
        status.textContent = "此浏览器无法启用声音，画面与交互仍可正常使用。";
      }
    };
  }

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) pause();
  });
  window.addEventListener("pagehide", () => {
    pause();
    audio && audio.dispose();
  });

  get("panel").disabled = false;
  draw(performance.now());
  window.singleEffect = {
    seek,
    play,
    pause,
    setMode,
    pressKey: triggerKey,
    render: () => draw(performance.now()),
    get frame() { return paintedFrame; },
    get liveState() { return live.sample(liveFrame); },
    get duration() { return length; },
    get mode() { return mode; },
  };
  if (!reduce) play();
})();
